package io.quarkus.workshop.fight;

public record Fight(Hero hero, Villain villain) {
}
